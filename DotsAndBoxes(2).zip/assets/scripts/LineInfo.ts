import { _decorator, Component, Node, Sprite } from 'cc';
import { GameManager } from './GameManager';
import { BoxInfo } from './BoxInfo';
const { ccclass, property } = _decorator;

@ccclass('LineInfo')
export class LineInfo extends Component {
    @property
    direction: 'H' | 'V' = 'H';

    @property
    row: number = 0;

    @property
    col: number = 0;

    isDrawn: boolean = false;

    onLoad() {
        this.node.on(Node.EventType.TOUCH_END, this.onClick, this);
    }

    onClick() {
        if (this.isDrawn) return;

        this.isDrawn = true;

        // 设置颜色
        const color = GameManager.Inst.getCurrentColor();
        const sprite = this.node.getComponent(Sprite);
        if (sprite) {
            sprite.color = color;
        } else {
            console.warn(`Line (${this.direction}_${this.row}_${this.col}) 未挂载 Sprite 组件`);
        }
        

        // 检查是否闭合了格子
        const closedBox = this.checkCompletedBoxes();

        if (!closedBox) {
            GameManager.Inst.switchTurn();
        }
    }

    checkCompletedBoxes(): boolean {
        let closed = false;
        const directionsToCheck: [number, number][] = [];
    
        if (this.direction === 'H') {
            if (this.row > 0) directionsToCheck.push([this.row - 1, this.col]);
            if (this.row < GameManager.Inst.rows - 1) directionsToCheck.push([this.row, this.col]);
        } else {
            if (this.col > 0) directionsToCheck.push([this.row, this.col - 1]);
            if (this.col < GameManager.Inst.cols - 1) directionsToCheck.push([this.row, this.col]);
        }
    
        for (const [r, c] of directionsToCheck) {
            const box = GameManager.Inst.getBox(r, c);
            if (box && GameManager.Inst.isBoxCompleted(box)) {
                box.node.active = true;
    
                box.setOwner(GameManager.Inst.getCurrentPlayer(), GameManager.Inst.getCurrentColor());
    
                // 🎉 加入玩家提示
                console.log(`🎉 玩家 ${GameManager.Inst.getCurrentPlayer() === 0 ? 'A' : 'B'} 成功占领了格子 Box_${r}_${c}`);
    
                GameManager.Inst.addScore();
                closed = true;
            }
        }
    
        return closed;
    }
    
    
}
