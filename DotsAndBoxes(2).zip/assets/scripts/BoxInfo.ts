import { _decorator, Component, Label, Color } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('BoxInfo')
export class BoxInfo extends Component {
    @property
    row: number = 0;

    @property
    col: number = 0;

    owner: number = -1;

    setOwner(playerId: number, color: Color) {
        this.owner = playerId;

        const labelNode = this.node.getChildByName('Label');
        if (!labelNode) {
            console.warn(`Box_${this.row}_${this.col} 缺少 Label 节点`);
            return;
        }

        const label = labelNode.getComponent(Label);
        if (!label) {
            console.warn(`Box_${this.row}_${this.col} 的 Label 节点未挂载 Label 组件`);
            return;
        }

        label.string = playerId === 0 ? 'A' : 'B';
        label.color = color;

        console.log(`Box_${this.row}_${this.col} 被玩家 ${playerId === 0 ? 'A' : 'B'} 占领`);
    }
}

