import { _decorator, Component, Node, Prefab, instantiate, Vec3 } from 'cc';
const { ccclass, property } = _decorator;
import { BoxInfo } from './BoxInfo';
import { GameManager } from './GameManager';
import { PointInfo } from './PointInfo';

@ccclass('BoardGenerator')
export class BoardGenerator extends Component {
    @property
    rows: number = 5;

    @property
    cols: number = 5;

    @property({ type: Prefab })
    pointPrefab: Prefab = null!;

    @property({ type: Prefab })
    boxPrefab: Prefab = null!;

    @property
    hSpacing: number = 100;

    @property
    vSpacing: number = 100;

    start() {
        this.generateBoard();

        if (GameManager.Inst) {
            GameManager.Inst.setBoardSize(this.rows, this.cols);
        }
    }

    generateBoard() {
        const startX = -((this.cols - 1) * this.hSpacing) / 2;
        const startY = ((this.rows - 1) * this.vSpacing) / 2;

        for (let r = 0; r < this.rows; r++) {
            for (let c = 0; c < this.cols; c++) {
                const x = startX + c * this.hSpacing;
                const y = startY - r * this.vSpacing;

                // 生成点
                const point = instantiate(this.pointPrefab);
                point.setPosition(new Vec3(x, y));
                point.name = `Point_${r}_${c}`;
                this.node.addChild(point);

                const info = point.getComponent(PointInfo);
                if (info) {
                    info.row = r;
                    info.col = c;
                }

                // 生成 box
                if (r < this.rows - 1 && c < this.cols - 1) {
                    const box = instantiate(this.boxPrefab);
                    box.setPosition(new Vec3(x + this.hSpacing / 2, y - this.vSpacing / 2));
                    box.name = `Box_${r}_${c}`;
                    box.active = false;
                    this.node.addChild(box);

                    const boxInfo = box.getComponent(BoxInfo);
                    if (boxInfo) {
                        boxInfo.row = r;
                        boxInfo.col = c;
                    }
                }
            }
        }
    }
}

