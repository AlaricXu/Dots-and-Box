import { _decorator, Component, Node, Label, Color } from 'cc';
import { BoxInfo } from './BoxInfo';
import { LineInfo } from './LineInfo';
const { ccclass, property } = _decorator;

@ccclass('GameManager')
export class GameManager extends Component {
    public static Inst: GameManager;

    @property(Node)
    boardRoot: Node = null!;

    @property(Label)
    scoreALabel: Label = null!;

    @property(Label)
    scoreBLabel: Label = null!;

    @property(Label)
    turnInfoLabel: Label = null!;


    currentPlayer: number = 0;
    scores: number[] = [0, 0];

    rows: number = 5;
    cols: number = 5;

    playerColors: Color[] = [new Color(0, 0, 255), new Color(255, 0, 0)];

    onLoad() {
        GameManager.Inst = this;
        this.updateUI();
    }

    switchTurn() {
        this.currentPlayer = 1 - this.currentPlayer;
        this.updateUI();
    }

    getCurrentPlayer() {
        return this.currentPlayer;
    }

    getCurrentColor(): Color {
        return this.playerColors[this.currentPlayer];
    }
    updateUI() {
        if (this.scoreALabel) this.scoreALabel.string = `玩家 A：${this.scores[0]}`;
        if (this.scoreBLabel) this.scoreBLabel.string = `玩家 B：${this.scores[1]}`;
        if (this.turnInfoLabel) this.turnInfoLabel.string = `当前回合：${this.currentPlayer === 0 ? 'A' : 'B'}`;
    }

    addScore() {
        this.scores[this.currentPlayer]++;
        this.updateUI();
    }

    getBox(row: number, col: number): BoxInfo | null {
        const name = `Box_${row}_${col}`;
        const node = this.boardRoot.getChildByName(name);
        if (!node) {
            console.warn(`找不到 Box_${row}_${col}`);
            return null;
        }
        return node.getComponent(BoxInfo);
    }
    

    isBoxCompleted(box: BoxInfo): boolean {
        const row = box.row;
        const col = box.col;
    
        const linesToCheck: [string, number, number][] = [
            ['H', row, col],
            ['H', row + 1, col],
            ['V', row, col],
            ['V', row, col + 1]
        ];
    
        for (const [dir, r, c] of linesToCheck) {
            if (r < 0 || c < 0 || r >= this.rows || c >= this.cols) {
                console.warn(`越界：Line_${dir}_${r}_${c} 不存在`);
                return false;
            }
    
            const lineName = `Line_${dir}_${r}_${c}`;
            const lineNode = this.boardRoot.getChildByName(lineName);
            const lineInfo = lineNode?.getComponent(LineInfo);
    
            if (!lineInfo || !lineInfo.isDrawn) {
                return false; // 缺线或线未点击
            }
        }
    
        return true;
    }
    

    setBoardSize(rows: number, cols: number) {
        this.rows = rows;
        this.cols = cols;
        console.log(`设置棋盘大小：${rows} x ${cols}`);
    }
}


