import { _decorator, Component, Node } from 'cc';
import { GameManager } from './GameManager';
const { ccclass, property } = _decorator;

@ccclass('PointInfo')
export class PointInfo extends Component {
    @property
    row: number = 0;

    @property
    col: number = 0;

    onLoad() {
        this.node.on(Node.EventType.TOUCH_END, this.onClick, this);
    }

    onClick() {
        GameManager.Inst.onPointClicked(this);
    }
}
