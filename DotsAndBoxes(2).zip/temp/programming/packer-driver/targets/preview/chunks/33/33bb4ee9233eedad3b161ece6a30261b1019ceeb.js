System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Label, Color, _dec, _class, _class2, _descriptor, _descriptor2, _crd, ccclass, property, BoxInfo;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Label = _cc.Label;
      Color = _cc.Color;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "40db6EvJAVD/6mLr+LslQOa", "BoxInfo", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Label', 'Color']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("BoxInfo", BoxInfo = (_dec = ccclass('BoxInfo'), _dec(_class = (_class2 = class BoxInfo extends Component {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "row", _descriptor, this);

          _initializerDefineProperty(this, "col", _descriptor2, this);

          this.owner = -1;
        }

        // -1 表示未归属；0：玩家1，1：玩家2
        setOwner(playerId) {
          this.owner = playerId; // 也可以在这里直接更改颜色或 Label 显示

          var label = this.node.getChildByName('Label');

          if (label) {
            var labelComp = label.getComponent(Label);

            if (labelComp) {
              labelComp.string = playerId === 0 ? "A" : "B";
              labelComp.color = playerId === 0 ? new Color(0, 0, 255) : new Color(255, 0, 0);
            }
          }
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "row", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 0;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "col", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 0;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=33bb4ee9233eedad3b161ece6a30261b1019ceeb.js.map