System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Node, Label, Color, BoxInfo, LineInfo, _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _class3, _crd, ccclass, property, GameManager;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfBoxInfo(extras) {
    _reporterNs.report("BoxInfo", "./BoxInfo", _context.meta, extras);
  }

  function _reportPossibleCrUseOfLineInfo(extras) {
    _reporterNs.report("LineInfo", "./LineInfo", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Label = _cc.Label;
      Color = _cc.Color;
    }, function (_unresolved_2) {
      BoxInfo = _unresolved_2.BoxInfo;
    }, function (_unresolved_3) {
      LineInfo = _unresolved_3.LineInfo;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "f08dfDB1yxHF4qvPN3C8/Pn", "GameManager", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'Label', 'Color']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("GameManager", GameManager = (_dec = ccclass('GameManager'), _dec2 = property(Node), _dec3 = property(Label), _dec4 = property(Label), _dec5 = property(Label), _dec(_class = (_class2 = (_class3 = class GameManager extends Component {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "boardRoot", _descriptor, this);

          _initializerDefineProperty(this, "scoreALabel", _descriptor2, this);

          _initializerDefineProperty(this, "scoreBLabel", _descriptor3, this);

          _initializerDefineProperty(this, "turnInfoLabel", _descriptor4, this);

          this.currentPlayer = 0;
          this.scores = [0, 0];
          this.rows = 5;
          this.cols = 5;
          this.playerColors = [new Color(0, 0, 255), new Color(255, 0, 0)];
        }

        onLoad() {
          GameManager.Inst = this;
          this.updateUI();
        }

        switchTurn() {
          this.currentPlayer = 1 - this.currentPlayer;
          this.updateUI();
        }

        getCurrentPlayer() {
          return this.currentPlayer;
        }

        getCurrentColor() {
          return this.playerColors[this.currentPlayer];
        }

        updateUI() {
          if (this.scoreALabel) this.scoreALabel.string = "\u73A9\u5BB6 A\uFF1A" + this.scores[0];
          if (this.scoreBLabel) this.scoreBLabel.string = "\u73A9\u5BB6 B\uFF1A" + this.scores[1];
          if (this.turnInfoLabel) this.turnInfoLabel.string = "\u5F53\u524D\u56DE\u5408\uFF1A" + (this.currentPlayer === 0 ? 'A' : 'B');
        }

        addScore() {
          this.scores[this.currentPlayer]++;
          this.updateUI();
        }

        getBox(row, col) {
          var name = "Box_" + row + "_" + col;
          var node = this.boardRoot.getChildByName(name);

          if (!node) {
            console.warn("\u627E\u4E0D\u5230 Box_" + row + "_" + col);
            return null;
          }

          return node.getComponent(_crd && BoxInfo === void 0 ? (_reportPossibleCrUseOfBoxInfo({
            error: Error()
          }), BoxInfo) : BoxInfo);
        }

        isBoxCompleted(box) {
          var row = box.row;
          var col = box.col;
          var linesToCheck = [['H', row, col], ['H', row + 1, col], ['V', row, col], ['V', row, col + 1]];

          for (var [dir, r, c] of linesToCheck) {
            if (r < 0 || c < 0 || r >= this.rows || c >= this.cols) {
              console.warn("\u8D8A\u754C\uFF1ALine_" + dir + "_" + r + "_" + c + " \u4E0D\u5B58\u5728");
              return false;
            }

            var lineName = "Line_" + dir + "_" + r + "_" + c;
            var lineNode = this.boardRoot.getChildByName(lineName);
            var lineInfo = lineNode == null ? void 0 : lineNode.getComponent(_crd && LineInfo === void 0 ? (_reportPossibleCrUseOfLineInfo({
              error: Error()
            }), LineInfo) : LineInfo);

            if (!lineInfo || !lineInfo.isDrawn) {
              return false; // 缺线或线未点击
            }
          }

          return true;
        }

        setBoardSize(rows, cols) {
          this.rows = rows;
          this.cols = cols;
          console.log("\u8BBE\u7F6E\u68CB\u76D8\u5927\u5C0F\uFF1A" + rows + " x " + cols);
        }

      }, _class3.Inst = void 0, _class3), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "boardRoot", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "scoreALabel", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "scoreBLabel", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "turnInfoLabel", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=506ba09eb83124cf93a76d3953dea81532fbabaf.js.map