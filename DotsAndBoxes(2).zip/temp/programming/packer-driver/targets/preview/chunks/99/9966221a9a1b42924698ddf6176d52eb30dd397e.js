System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Node, Sprite, GameManager, _dec, _class, _class2, _descriptor, _descriptor2, _descriptor3, _crd, ccclass, property, LineInfo;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfGameManager(extras) {
    _reporterNs.report("GameManager", "./GameManager", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Sprite = _cc.Sprite;
    }, function (_unresolved_2) {
      GameManager = _unresolved_2.GameManager;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "9f5b5dNd0dEyZwKBqBQ/c8d", "LineInfo", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'Sprite']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("LineInfo", LineInfo = (_dec = ccclass('LineInfo'), _dec(_class = (_class2 = class LineInfo extends Component {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "direction", _descriptor, this);

          _initializerDefineProperty(this, "row", _descriptor2, this);

          _initializerDefineProperty(this, "col", _descriptor3, this);

          this.isDrawn = false;
        }

        onLoad() {
          this.node.on(Node.EventType.TOUCH_END, this.onClick, this);
        }

        onClick() {
          if (this.isDrawn) return;
          this.isDrawn = true; // 设置颜色

          var color = (_crd && GameManager === void 0 ? (_reportPossibleCrUseOfGameManager({
            error: Error()
          }), GameManager) : GameManager).Inst.getCurrentColor();
          var sprite = this.node.getComponent(Sprite);

          if (sprite) {
            sprite.color = color;
          } else {
            console.warn("Line (" + this.direction + "_" + this.row + "_" + this.col + ") \u672A\u6302\u8F7D Sprite \u7EC4\u4EF6");
          } // 检查是否闭合了格子


          var closedBox = this.checkCompletedBoxes();

          if (!closedBox) {
            (_crd && GameManager === void 0 ? (_reportPossibleCrUseOfGameManager({
              error: Error()
            }), GameManager) : GameManager).Inst.switchTurn();
          }
        }

        checkCompletedBoxes() {
          var closed = false;
          var directionsToCheck = [];

          if (this.direction === 'H') {
            if (this.row > 0) directionsToCheck.push([this.row - 1, this.col]);
            if (this.row < (_crd && GameManager === void 0 ? (_reportPossibleCrUseOfGameManager({
              error: Error()
            }), GameManager) : GameManager).Inst.rows - 1) directionsToCheck.push([this.row, this.col]);
          } else {
            if (this.col > 0) directionsToCheck.push([this.row, this.col - 1]);
            if (this.col < (_crd && GameManager === void 0 ? (_reportPossibleCrUseOfGameManager({
              error: Error()
            }), GameManager) : GameManager).Inst.cols - 1) directionsToCheck.push([this.row, this.col]);
          }

          for (var [r, c] of directionsToCheck) {
            var box = (_crd && GameManager === void 0 ? (_reportPossibleCrUseOfGameManager({
              error: Error()
            }), GameManager) : GameManager).Inst.getBox(r, c);

            if (box && (_crd && GameManager === void 0 ? (_reportPossibleCrUseOfGameManager({
              error: Error()
            }), GameManager) : GameManager).Inst.isBoxCompleted(box)) {
              box.node.active = true;
              box.setOwner((_crd && GameManager === void 0 ? (_reportPossibleCrUseOfGameManager({
                error: Error()
              }), GameManager) : GameManager).Inst.getCurrentPlayer(), (_crd && GameManager === void 0 ? (_reportPossibleCrUseOfGameManager({
                error: Error()
              }), GameManager) : GameManager).Inst.getCurrentColor()); // 🎉 加入玩家提示

              console.log("\uD83C\uDF89 \u73A9\u5BB6 " + ((_crd && GameManager === void 0 ? (_reportPossibleCrUseOfGameManager({
                error: Error()
              }), GameManager) : GameManager).Inst.getCurrentPlayer() === 0 ? 'A' : 'B') + " \u6210\u529F\u5360\u9886\u4E86\u683C\u5B50 Box_" + r + "_" + c);
              (_crd && GameManager === void 0 ? (_reportPossibleCrUseOfGameManager({
                error: Error()
              }), GameManager) : GameManager).Inst.addScore();
              closed = true;
            }
          }

          return closed;
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "direction", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 'H';
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "row", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 0;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "col", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 0;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=9966221a9a1b42924698ddf6176d52eb30dd397e.js.map