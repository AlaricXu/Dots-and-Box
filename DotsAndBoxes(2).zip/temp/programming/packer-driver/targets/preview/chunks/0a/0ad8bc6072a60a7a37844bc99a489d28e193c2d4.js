System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Prefab, instantiate, Vec3, LineInfo, BoxInfo, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _crd, ccclass, property, BoardGenerator;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfLineInfo(extras) {
    _reporterNs.report("LineInfo", "./LineInfo", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBoxInfo(extras) {
    _reporterNs.report("BoxInfo", "./BoxInfo", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Prefab = _cc.Prefab;
      instantiate = _cc.instantiate;
      Vec3 = _cc.Vec3;
    }, function (_unresolved_2) {
      LineInfo = _unresolved_2.LineInfo;
    }, function (_unresolved_3) {
      BoxInfo = _unresolved_3.BoxInfo;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "88d1b2/1rlDH6KuspdihsIE", "BoardGenerator", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'Prefab', 'instantiate', 'Vec3']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("BoardGenerator", BoardGenerator = (_dec = ccclass('BoardGenerator'), _dec2 = property({
        type: Prefab
      }), _dec3 = property({
        type: Prefab
      }), _dec4 = property({
        type: Prefab
      }), _dec5 = property({
        tooltip: '点之间的水平间距'
      }), _dec6 = property({
        tooltip: '点之间的垂直间距'
      }), _dec(_class = (_class2 = class BoardGenerator extends Component {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "rows", _descriptor, this);

          _initializerDefineProperty(this, "cols", _descriptor2, this);

          _initializerDefineProperty(this, "pointPrefab", _descriptor3, this);

          _initializerDefineProperty(this, "linePrefab", _descriptor4, this);

          _initializerDefineProperty(this, "boxPrefab", _descriptor5, this);

          _initializerDefineProperty(this, "hSpacing", _descriptor6, this);

          _initializerDefineProperty(this, "vSpacing", _descriptor7, this);
        }

        start() {
          this.generateBoard();
        }

        generateBoard() {
          var startX = -((this.cols - 1) * this.hSpacing) / 2;
          var startY = (this.rows - 1) * this.vSpacing / 2;

          for (var r = 0; r < this.rows; r++) {
            for (var c = 0; c < this.cols; c++) {
              var x = startX + c * this.hSpacing;
              var y = startY - r * this.vSpacing; // 生成点

              var point = instantiate(this.pointPrefab);
              point.setPosition(new Vec3(x, y));
              this.node.addChild(point); // 生成右边横线（H）

              if (c < this.cols - 1) {
                var hLine = instantiate(this.linePrefab);
                hLine.setPosition(new Vec3(x + this.hSpacing / 2, y));
                this.node.addChild(hLine); // 设置方向（LineInfo 脚本）

                var info = hLine.getComponent(_crd && LineInfo === void 0 ? (_reportPossibleCrUseOfLineInfo({
                  error: Error()
                }), LineInfo) : LineInfo);

                if (info) {
                  info.direction = 'H';
                  info.row = r;
                  info.col = c;
                }
              } // 生成下方竖线（V）


              if (r < this.rows - 1) {
                var vLine = instantiate(this.linePrefab);
                vLine.setPosition(new Vec3(x, y - this.vSpacing / 2));
                vLine.setScale(new Vec3(1, 1, 1));
                vLine.angle = 90; // 旋转90度为垂直

                this.node.addChild(vLine);

                var _info = vLine.getComponent(_crd && LineInfo === void 0 ? (_reportPossibleCrUseOfLineInfo({
                  error: Error()
                }), LineInfo) : LineInfo);

                if (_info) {
                  _info.direction = 'V';
                  _info.row = r;
                  _info.col = c;
                }
              } // 生成格子


              if (r < this.rows - 1 && c < this.cols - 1) {
                var box = instantiate(this.boxPrefab);
                box.setPosition(new Vec3(x + this.hSpacing / 2, y - this.vSpacing / 2));
                this.node.addChild(box);
                var boxInfo = box.getComponent(_crd && BoxInfo === void 0 ? (_reportPossibleCrUseOfBoxInfo({
                  error: Error()
                }), BoxInfo) : BoxInfo);

                if (boxInfo) {
                  boxInfo.row = r;
                  boxInfo.col = c;
                }
              }
            }
          }
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "rows", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 5;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "cols", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 5;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "pointPrefab", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "linePrefab", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "boxPrefab", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "hSpacing", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 100;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "vSpacing", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 100;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=0ad8bc6072a60a7a37844bc99a489d28e193c2d4.js.map