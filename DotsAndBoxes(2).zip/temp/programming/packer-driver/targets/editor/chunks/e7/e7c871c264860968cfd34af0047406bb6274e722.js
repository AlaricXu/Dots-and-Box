System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Prefab, instantiate, Vec3, BoxInfo, GameManager, PointInfo, _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _crd, ccclass, property, BoardGenerator;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfBoxInfo(extras) {
    _reporterNs.report("BoxInfo", "./BoxInfo", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameManager(extras) {
    _reporterNs.report("GameManager", "./GameManager", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPointInfo(extras) {
    _reporterNs.report("PointInfo", "./PointInfo", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Prefab = _cc.Prefab;
      instantiate = _cc.instantiate;
      Vec3 = _cc.Vec3;
    }, function (_unresolved_2) {
      BoxInfo = _unresolved_2.BoxInfo;
    }, function (_unresolved_3) {
      GameManager = _unresolved_3.GameManager;
    }, function (_unresolved_4) {
      PointInfo = _unresolved_4.PointInfo;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "88d1b2/1rlDH6KuspdihsIE", "BoardGenerator", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Node', 'Prefab', 'instantiate', 'Vec3']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("BoardGenerator", BoardGenerator = (_dec = ccclass('BoardGenerator'), _dec2 = property({
        type: Prefab
      }), _dec3 = property({
        type: Prefab
      }), _dec(_class = (_class2 = class BoardGenerator extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "rows", _descriptor, this);

          _initializerDefineProperty(this, "cols", _descriptor2, this);

          _initializerDefineProperty(this, "pointPrefab", _descriptor3, this);

          _initializerDefineProperty(this, "boxPrefab", _descriptor4, this);

          _initializerDefineProperty(this, "hSpacing", _descriptor5, this);

          _initializerDefineProperty(this, "vSpacing", _descriptor6, this);
        }

        start() {
          this.generateBoard();

          if ((_crd && GameManager === void 0 ? (_reportPossibleCrUseOfGameManager({
            error: Error()
          }), GameManager) : GameManager).Inst) {
            (_crd && GameManager === void 0 ? (_reportPossibleCrUseOfGameManager({
              error: Error()
            }), GameManager) : GameManager).Inst.setBoardSize(this.rows, this.cols);
          }
        }

        generateBoard() {
          const startX = -((this.cols - 1) * this.hSpacing) / 2;
          const startY = (this.rows - 1) * this.vSpacing / 2;

          for (let r = 0; r < this.rows; r++) {
            for (let c = 0; c < this.cols; c++) {
              const x = startX + c * this.hSpacing;
              const y = startY - r * this.vSpacing; // 生成点

              const point = instantiate(this.pointPrefab);
              point.setPosition(new Vec3(x, y));
              point.name = `Point_${r}_${c}`;
              this.node.addChild(point);
              const info = point.getComponent(_crd && PointInfo === void 0 ? (_reportPossibleCrUseOfPointInfo({
                error: Error()
              }), PointInfo) : PointInfo);

              if (info) {
                info.row = r;
                info.col = c;
              } // 生成 box


              if (r < this.rows - 1 && c < this.cols - 1) {
                const box = instantiate(this.boxPrefab);
                box.setPosition(new Vec3(x + this.hSpacing / 2, y - this.vSpacing / 2));
                box.name = `Box_${r}_${c}`;
                box.active = false;
                this.node.addChild(box);
                const boxInfo = box.getComponent(_crd && BoxInfo === void 0 ? (_reportPossibleCrUseOfBoxInfo({
                  error: Error()
                }), BoxInfo) : BoxInfo);

                if (boxInfo) {
                  boxInfo.row = r;
                  boxInfo.col = c;
                }
              }
            }
          }
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "rows", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 5;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "cols", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 5;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "pointPrefab", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "boxPrefab", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "hSpacing", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 100;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "vSpacing", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 100;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=e7c871c264860968cfd34af0047406bb6274e722.js.map